package com.login;

import java.io.IOException;

import jakarta.security.auth.message.callback.PrivateKeyCallback.Request;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet ("/login")
public class login extends HttpServlet{

	protected void doGet (HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException  {
		
	String uname = req.getParameter("fullname");
	String pass= req.getParameter("password");
	
	if (uname.equals("emmy") && pass.equals("123"))
	{
		HttpSession session= req.getSession();
		session.setAttribute("username", uname );;
		res.sendRedirect("reg.jsp");
		
	}else {
		
		res.sendRedirect("login.jsp");
	}
		
	}}
	
		


